using Microsoft.AspNetCore.Mvc;
using DocumentManagement.Features.Services.Interfaces;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.Net.Http.Headers;

[ApiController]
[Route("api/documents")]
public class DocumentController : ControllerBase
{
    private readonly IDocumentService _documentService;
    private readonly FileExtensionContentTypeProvider _contentTypeProvider;

    public DocumentController(IDocumentService documentService)
    {
        _documentService = documentService;
        _contentTypeProvider = new FileExtensionContentTypeProvider();
        
        // Add or override common mappings for better viewing
        _contentTypeProvider.Mappings[".sql"] = "text/plain";
        _contentTypeProvider.Mappings[".json"] = "application/json";
        _contentTypeProvider.Mappings[".log"] = "text/plain";
        _contentTypeProvider.Mappings[".cs"] = "text/plain";
        _contentTypeProvider.Mappings[".razor"] = "text/plain";
        _contentTypeProvider.Mappings[".config"] = "text/xml";
        _contentTypeProvider.Mappings[".md"] = "text/plain";
        _contentTypeProvider.Mappings[".yml"] = "text/plain";
        _contentTypeProvider.Mappings[".yaml"] = "text/plain";
        _contentTypeProvider.Mappings[".bat"] = "text/plain";
        _contentTypeProvider.Mappings[".ps1"] = "text/plain";
        _contentTypeProvider.Mappings[".py"] = "text/plain";
        _contentTypeProvider.Mappings[".js"] = "text/plain";
        _contentTypeProvider.Mappings[".ts"] = "text/plain";
        _contentTypeProvider.Mappings[".css"] = "text/plain";
        _contentTypeProvider.Mappings[".less"] = "text/plain";
        _contentTypeProvider.Mappings[".scss"] = "text/plain";
        _contentTypeProvider.Mappings[".env"] = "text/plain";
        _contentTypeProvider.Mappings[".gitignore"] = "text/plain";
        _contentTypeProvider.Mappings[".txt"] = "text/plain";
        _contentTypeProvider.Mappings[".csv"] = "text/csv";
    }

    [HttpGet("download/{id}")]
    public async Task<IActionResult> Download(int id)
    {
        try
        {
            var document = await _documentService.GetDocumentByIdAsync(id);
            if (document == null)
                return NotFound("Document not found");

            if (!System.IO.File.Exists(document.FilePath))
                return NotFound("File not found on server");

            // Ensure the filename has the correct extension
            var extension = Path.GetExtension(document.FileName);
            var downloadName = document.Name.EndsWith(extension, StringComparison.OrdinalIgnoreCase) 
                ? document.Name 
                : document.Name + extension;

            return PhysicalFile(document.FilePath, document.FileType ?? "application/octet-stream", downloadName);
        }
        catch (Exception ex)
        {
            return BadRequest(ex.Message);
        }
    }

    [HttpGet("view/{id}")]
    public async Task<IActionResult> View(int id)
    {
        try
        {
            var document = await _documentService.GetDocumentByIdAsync(id);
            if (document == null)
                return NotFound("Document not found");

            if (!System.IO.File.Exists(document.FilePath))
                return NotFound("File not found on server");

            // Try to get a better content type based on file extension
            if (!_contentTypeProvider.TryGetContentType(document.FileName, out var contentType))
            {
                contentType = document.FileType ?? "application/octet-stream";
            }

            // For viewing, we want to try and show it in the browser
            var extension = Path.GetExtension(document.FileName);
            var viewName = document.Name.EndsWith(extension, StringComparison.OrdinalIgnoreCase) 
                ? document.Name 
                : document.Name + extension;

            // Improve text viewing with explicit charset
            if (contentType.StartsWith("text/") && !contentType.Contains("charset"))
            {
                contentType += "; charset=utf-8";
            }

            // Use PhysicalFile for better performance and reliability
            // Manually set Content-Disposition to inline
            var contentDisposition = new ContentDispositionHeaderValue("inline");
            contentDisposition.SetHttpFileName(viewName);
            Response.Headers[HeaderNames.ContentDisposition] = contentDisposition.ToString();

            return PhysicalFile(document.FilePath, contentType);
        }
        catch (Exception ex)
        {
            return BadRequest(ex.Message);
        }
    }
}
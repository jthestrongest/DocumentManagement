using DocumentManagement.Components;
using DocumentManagement.Features.Data;
using DocumentManagement.Features.Helpers;
using DocumentManagement.Features.Repositories.Implementations;
using DocumentManagement.Features.Repositories.Interfaces;
using DocumentManagement.Features.Services.Implementations;
using DocumentManagement.Features.Services.Interfaces;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Components.Server;
using Microsoft.EntityFrameworkCore;
using MudBlazor.Services;

var builder = WebApplication.CreateBuilder(args);

// Add MudBlazor services
builder.Services.AddMudServices();

builder.Services.AddControllers();


// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents()
    .AddHubOptions(options =>
    {
        options.MaximumReceiveMessageSize = 250 * 1024 * 1024; // 250MB for SignalR
    });

builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseMySql(
        builder.Configuration.GetConnectionString("DocumentManagement"),
        ServerVersion.AutoDetect(builder.Configuration.GetConnectionString("DocumentManagement"))
        ));

builder.Services.AddScoped<IUserRepository, UserRepository>();
builder.Services.AddScoped<IUserService, UserService>();
builder.Services.AddScoped<IDocumentRepository, DocumentRepository>();
builder.Services.AddScoped<IDocumentService, DocumentService>();

builder.Services.AddScoped<AuthStateProvider>();
builder.Services.AddScoped<AuthenticationStateProvider>(sp =>
        sp.GetRequiredService<AuthStateProvider>());

// Configure Blazor circuit options for long-running operations like file uploads
builder.Services.Configure<CircuitOptions>(options =>
{
    options.DisconnectedCircuitMaxRetained = 100;
    options.DisconnectedCircuitRetentionPeriod = TimeSpan.FromMinutes(5);
});

builder.Services.AddAuthentication("Cookies")
    .AddCookie("Cookies", options =>
    {
        options.LoginPath = "/login";
    });

builder.Services.AddAuthorizationCore();
builder.Services.AddAuthorization();

var app = builder.Build();

// Create uploads directory if it doesn't exist
var uploadsPath = Path.Combine(app.Environment.ContentRootPath, "uploads");
if (!Directory.Exists(uploadsPath))
{
    Directory.CreateDirectory(uploadsPath);
}

// Ensure database is created and updated
using (var scope = app.Services.CreateScope())
{
    var dbContext = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    var userService = scope.ServiceProvider.GetRequiredService<IUserService>();

    // Ensure database is created
    dbContext.Database.EnsureCreated();

    // Fix for missing columns if the database already existed
    try
    {
        await dbContext.Database.ExecuteSqlRawAsync("ALTER TABLE Users ADD COLUMN IF NOT EXISTS EmailNotifications TINYINT(1) NOT NULL DEFAULT 1;");
        await dbContext.Database.ExecuteSqlRawAsync("ALTER TABLE Users ADD COLUMN IF NOT EXISTS PushNotifications TINYINT(1) NOT NULL DEFAULT 0;");
        await dbContext.Database.ExecuteSqlRawAsync("ALTER TABLE Users ADD COLUMN IF NOT EXISTS DarkMode TINYINT(1) NOT NULL DEFAULT 0;");
    }
    catch { /* Ignore errors if columns already exist or dialect doesn't support IF NOT EXISTS */ }
    
    var users = await userService.GetAllUsers();
}

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}



app.MapControllers();

app.UseHttpsRedirection();

app.UseAuthentication();
app.UseAuthorization();

app.UseAntiforgery();

app.MapStaticAssets();
app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();

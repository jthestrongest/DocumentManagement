# Quick Start Guide - Document Management System

## 🎯 Getting Started

### Step 1: Start the Application
```powershell
cd C:\Enggo\DocumentManagement\
dotnet run
```

Navigate to: `https://localhost:7xxx` (port shown in terminal)

---

## 👤 User Roles & Accounts

### Admin Access:
- Username: `admin`
- Password: `admin123` (or register new admin)
- Can: Manage users, view dashboard, activity log, register admins

### Regular User Access:
- Username: `testuser`
- Password: `password123` (or register new user)
- Can: Upload/download documents, search, change settings

---

## 📚 Main Workflows

### For Regular Users:

#### 1. **Register & Login**
- Click "Don't have an account? Register here"
- Fill registration form
- Select "User" role
- Login with new credentials

#### 2. **Upload Documents**
- Click "Documents" in navigation menu
- Click "Upload Document" button
- Fill in document name and description
- Select file (max 50MB)
- Click "Upload"

#### 3. **Search Documents**
- Click "Search" in navigation menu
- Enter search terms in name field
- Filter by file type if needed
- Click "Search" button

#### 4. **Manage Settings**
- Click "Settings" in navigation menu
- Change password in "Account Settings" tab
- Adjust preferences (notifications, page size)
- View security information

---

### For Administrators:

#### 1. **View Dashboard**
- Click "Dashboard" in navigation menu
- See total users, documents, admins, storage used
- View recently uploaded documents

#### 2. **Manage Users**
- Click "Users" in navigation menu
- Click "Add User" to create new user
- Click edit/delete buttons for existing users
- Assign roles (Admin or User)

#### 3. **Register Admin**
- Click "Register Admin" in navigation menu
- Fill admin registration form
- Create new admin account with full permissions

#### 4. **View Activity Log**
- Click "Activity Log" in navigation menu
- See timeline of all system activities
- Search by user or activity type
- Filter by activity type

---

## 🎨 Features by Page

| Page | Route | Access | Purpose |
|------|-------|--------|---------|
| Home | `/` | All Users | Welcome page |
| Documents | `/documents` | All Users | View/manage documents |
| Upload | `/documents/upload` | All Users | Upload new documents |
| Search | `/documents/search` | All Users | Search documents |
| Settings | `/settings` | All Users | User settings & preferences |
| Help | `/help` | All Users | Documentation & FAQ |
| Dashboard | `/dashboard` | Admin Only | System statistics |
| Users | `/users` | Admin Only | User management |
| Activity Log | `/activity-log` | Admin Only | System activity tracking |
| Register Admin | `/register-admin` | Admin Only | Create admin accounts |

---

## 🔑 Key Functions

### Authentication
- ✅ Register with email and username
- ✅ Login with credentials
- ✅ Logout with confirmation
- ✅ Password hashing (SHA256)
- ✅ Role-based access (Admin/User)

### Document Management
- ✅ Upload documents (up to 50MB)
- ✅ View document list with details
- ✅ Search by name/description
- ✅ Filter by file type
- ✅ Download documents
- ✅ Delete (soft delete)

### Admin Features
- ✅ Create/edit/delete users
- ✅ Assign user roles
- ✅ View system dashboard
- ✅ Monitor activity log
- ✅ Register admin users

### User Settings
- ✅ Change password
- ✅ Toggle notifications
- ✅ Customize page size
- ✅ View security info

---

## 🌙 UI Features

### Theme Toggle
- Click the **moon/auto icon** in top app bar
- Switches between light and dark mode
- Your preference persists during session

### Navigation
- **Hamburger menu** (☰) - Toggle navigation drawer
- **Profile button** - Shows your username
- **Logout button** - Logout with confirmation
- **Settings gear** - User settings

---

## 📊 Navigation Menu

**All Users See:**
- Home
- Documents
- Search
- Settings
- Help

**Admins Additionally See:**
- Dashboard
- Users
- Activity Log
- Register Admin

---

## 💾 Database

### Location:
```
Server: localhost
Database: documentdb
User: root
```

### Tables:
- `Users` - User accounts with roles
- `Documents` - Uploaded documents
- `__EFMigrationsHistory` - Migration tracking

### Data Retention:
- Deleted users marked as `IsActive = false`
- Deleted documents marked as `IsActive = false`
- Both can be recovered by admin

---

## ⚙️ Configuration

### Connection String (appsettings.json):
```json
{
  "ConnectionStrings": {
    "DocumentManagement": "Server=localhost;Database=documentdb;User=root;Password=;"
  }
}
```

### Database Migration:
```powershell
# Create migration
dotnet ef migrations add MigrationName

# Apply migrations
dotnet ef database update
```

---

## 🆘 Troubleshooting

### "Invalid username or password"
- Verify credentials are correct
- Check if account is active (not soft-deleted)
- Ensure password matches database (case-sensitive)

### "Confirm Delete" dialog on logout
- This is normal - just click "Logout" to confirm
- You'll be logged out and redirected to login page

### Documents won't upload
- Check file size (max 50MB)
- Ensure file format is supported
- Verify uploads folder exists

### Can't access Admin features
- Verify you're logged in as Admin user
- Check User role in Users management
- Ensure account has Admin role

---

## 📞 Support

**For Help:**
- Visit `/help` page in application
- Check FAQ section
- View Getting Started guide
- Contact system administrator

---

## ✨ Tips & Tricks

1. **Search Optimization** - Use specific keywords for better results
2. **File Organization** - Use descriptive document names
3. **Backup** - Regularly backup important documents
4. **Activity Log** - Check activity log for security audit trail
5. **Theme** - Use light mode for better readability during day
6. **Notifications** - Enable in settings to stay updated

---

**Happy Documenting! 📄✨**

using System.ComponentModel.DataAnnotations;

namespace DocumentManagement.Features.Data.Models
{
    public class Document : BaseModel
    {
        [Key]
        public int Id { get; set; }

        [Required, MaxLength(255)]
        public string Name { get; set; }

        [MaxLength(1000)]
        public string Description { get; set; }

        [Required]
        public string FilePath { get; set; }

        [Required]
        public string FileName { get; set; }

        [Required]
        public long FileSize { get; set; }

        [Required, MaxLength(50)]
        public string FileType { get; set; }

        [Required]
        public DateTime UploadedDate { get; set; }

        [Required]
        public int UploadedByUserId { get; set; }

        public bool IsActive { get; set; } = true;

        // Navigation property
        public virtual User UploadedByUser { get; set; }
    }
}

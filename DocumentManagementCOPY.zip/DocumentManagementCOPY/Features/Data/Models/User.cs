using DocumentManagement.Features.Data.Enums;
using System.ComponentModel.DataAnnotations;

namespace DocumentManagement.Features.Data.Models
{
    public class User : BaseModel
    {
        [Key]
        public int Id { get; set; }
        [Required, MaxLength(100)]
        public string Name { get; set; }
        [Required, MaxLength(100), EmailAddress]
        public string Email { get; set; }
        [Required, MaxLength(20)]
        public string Username { get; set; }
        [Required, MaxLength(256)]
        public string Password { get; set; }
        public Roles Role { get; set; } = Roles.User;
        public bool IsActive { get; set; } = true;
        
        // Preferences
        public bool EmailNotifications { get; set; } = true;
        public bool PushNotifications { get; set; } = false;
        public bool DarkMode { get; set; } = false;
    }
}

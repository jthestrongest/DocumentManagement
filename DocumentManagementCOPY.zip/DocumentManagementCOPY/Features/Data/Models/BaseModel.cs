﻿namespace DocumentManagement.Features.Data.Models
{
    public class BaseModel
    {
    }
}

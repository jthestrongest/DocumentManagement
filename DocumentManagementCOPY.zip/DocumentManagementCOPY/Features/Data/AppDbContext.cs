using DocumentManagement.Components.Pages;
using DocumentManagement.Features.Data.Models;
using Microsoft.EntityFrameworkCore;
namespace DocumentManagement.Features.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }

        public DbSet<Document> Documents { get; set; }
        public DbSet<User> Users { get; set; }

    }
}



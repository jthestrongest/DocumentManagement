namespace DocumentManagement.Features.Data.Enums
{
    public enum Roles
    {
        Admin,
        User
    }
}

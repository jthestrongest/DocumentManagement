using MudBlazor;

namespace DocumentManagement.Features.Helpers
{
    public static class DocumentHelper
    {
        public static string GetFileIcon(string contentType)
        {
            if (string.IsNullOrEmpty(contentType)) return Icons.Custom.FileFormats.FileDocument;
            
            contentType = contentType.ToLower();
            if (contentType.Contains("pdf")) return Icons.Custom.FileFormats.FilePdf;
            if (contentType.Contains("word") || contentType.Contains("officedocument.wordprocessingml")) return Icons.Custom.FileFormats.FileWord;
            if (contentType.Contains("excel") || contentType.Contains("officedocument.spreadsheetml")) return Icons.Custom.FileFormats.FileExcel;
            if (contentType.Contains("image")) return Icons.Custom.FileFormats.FileImage;
            if (contentType.Contains("text") || contentType.Contains("json") || contentType.Contains("xml") || contentType.Contains("javascript")) return Icons.Material.Filled.Article;
            if (contentType.Contains("zip") || contentType.Contains("compressed") || contentType.Contains("archive")) return Icons.Material.Filled.Archive;
            if (contentType.Contains("audio")) return Icons.Material.Filled.AudioFile;
            
            return Icons.Custom.FileFormats.FileDocument;
        }

        public static Color GetAvatarColor(string contentType)
        {
            if (string.IsNullOrEmpty(contentType)) return Color.Default;
            
            contentType = contentType.ToLower();
            if (contentType.Contains("pdf")) return Color.Error;
            if (contentType.Contains("word") || contentType.Contains("officedocument.wordprocessingml")) return Color.Info;
            if (contentType.Contains("excel") || contentType.Contains("officedocument.spreadsheetml")) return Color.Success;
            if (contentType.Contains("image")) return Color.Warning;
            if (contentType.Contains("text") || contentType.Contains("json") || contentType.Contains("xml")) return Color.Primary;
            if (contentType.Contains("zip") || contentType.Contains("compressed") || contentType.Contains("archive")) return Color.Secondary;
            
            return Color.Default;
        }

        public static string GetShortType(string contentType)
        {
            if (string.IsNullOrEmpty(contentType)) return "Unknown";
            
            if (contentType.Contains("officedocument.wordprocessingml")) return "DOCX";
            if (contentType.Contains("officedocument.spreadsheetml")) return "XLSX";
            if (contentType.Contains("officedocument.presentationml")) return "PPTX";
            
            var parts = contentType.Split('/');
            var type = parts.Length > 1 ? parts[1].ToUpper() : contentType.ToUpper();
            
            // Clean up common long types
            if (type.Contains("VND.MS-EXCEL")) return "XLS";
            if (type.Contains("MSWORD")) return "DOC";
            if (type.Contains("PLAIN")) return "TXT";
            
            return type;
        }

        public static string FormatFileSize(long bytes)
        {
            string[] sizes = { "B", "KB", "MB", "GB" };
            double len = bytes;
            int order = 0;
            while (len >= 1024 && order < sizes.Length - 1)
            {
                order++;
                len = len / 1024;
            }
            return $"{len:0.##} {sizes[order]}";
        }

        public static bool IsVideoFile(string fileName, string contentType)
        {
            if (contentType?.StartsWith("video/", StringComparison.OrdinalIgnoreCase) == true)
            {
                return true;
            }

            string fileExtension = Path.GetExtension(fileName)?.ToLower();
            string[] videoExtensions = { ".mp4", ".avi", ".mov", ".mkv", ".flv", ".wmv", ".webm", ".m4v", ".mpg", ".mpeg" };
            return videoExtensions.Contains(fileExtension);
        }
    }
}

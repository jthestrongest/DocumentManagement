﻿using DocumentManagement.Features.Data.Enums;
using Microsoft.AspNetCore.Components.Authorization;
using System.Security.Claims;

namespace DocumentManagement.Features.Helpers
{
    public class AuthStateProvider : AuthenticationStateProvider
    {
        private ClaimsPrincipal _user =
            new ClaimsPrincipal(new ClaimsIdentity());

        public override Task<AuthenticationState> GetAuthenticationStateAsync()
        {
            return Task.FromResult(new AuthenticationState(_user));
        }

        public void SetUser(string username, Roles role)
        {
            var identity = new ClaimsIdentity(new[]
            {
                new Claim(ClaimTypes.Name, username),
                new Claim(ClaimTypes.Role, role.ToString())
            }, "custom");

            _user = new ClaimsPrincipal(identity);
            NotifyAuthenticationStateChanged(GetAuthenticationStateAsync());
        }

        public void Logout()
        {
            _user = new ClaimsPrincipal(new ClaimsIdentity());
            NotifyAuthenticationStateChanged(GetAuthenticationStateAsync());
        }

        public bool IsAuthenticated => _user?.Identity?.IsAuthenticated ?? false;
    }
}

using DocumentManagement.Features.Data.Models;

namespace DocumentManagement.Features.Repositories.Interfaces
{
    public interface IDocumentRepository
    {
        Task<List<Document>> GetAllAsync();
        Task<Document?> GetByIdAsync(int id);
        Task<List<Document>> GetByUserIdAsync(int userId);
        Task AddAsync(Document document);
        Task UpdateAsync(Document document);
        Task DeleteAsync(int id);
    }
}

﻿namespace DocumentManagement.Features.Repositories.Implementations
{
    public class AuthRepository
    {
    }
}

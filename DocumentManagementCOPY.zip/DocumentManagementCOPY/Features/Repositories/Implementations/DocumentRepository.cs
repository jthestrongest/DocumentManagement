using DocumentManagement.Features.Data;
using DocumentManagement.Features.Data.Models;
using DocumentManagement.Features.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace DocumentManagement.Features.Repositories.Implementations
{
    public class DocumentRepository : IDocumentRepository
    {
        private readonly AppDbContext _context;

        public DocumentRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<Document>> GetAllAsync()
            => await _context.Documents
                .Include(d => d.UploadedByUser)
                .Where(d => d.IsActive)
                .ToListAsync();

        public async Task<Document?> GetByIdAsync(int id)
            => await _context.Documents
                .Include(d => d.UploadedByUser)
                .FirstOrDefaultAsync(d => d.Id == id && d.IsActive);

        public async Task<List<Document>> GetByUserIdAsync(int userId)
            => await _context.Documents
                .Include(d => d.UploadedByUser)
                .Where(d => d.UploadedByUserId == userId && d.IsActive)
                .ToListAsync();

        public async Task AddAsync(Document document)
        {
            _context.Documents.Add(document);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(Document document)
        {
            _context.Documents.Update(document);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var document = await _context.Documents.FindAsync(id);
            if (document == null) return;

            _context.Documents.Remove(document);
            await _context.SaveChangesAsync();
        }
    }
}

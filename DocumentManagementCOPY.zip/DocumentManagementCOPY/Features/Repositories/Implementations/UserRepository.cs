﻿using DocumentManagement.Features.Data;
using DocumentManagement.Features.Data.Models;
using DocumentManagement.Features.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace DocumentManagement.Features.Repositories.Implementations
{
    public class UserRepository : IUserRepository
    {
        private readonly AppDbContext _context;
        public UserRepository(AppDbContext context)
        {
            _context = context;
        }
        public async Task AddAsync(User user)
        {
            _context.Users.Add(user);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var user = await _context.Users.FindAsync(id);
            if (user == null) return;

            // Soft delete - mark as inactive instead of deleting
            user.IsActive = false;
            _context.Users.Update(user);
            await _context.SaveChangesAsync();
        }

        public async Task<List<User>> GetAllAsync() => await _context.Users.Where(u => u.IsActive).ToListAsync();

        public async Task<User?> GetByIdAsync(int id) => await _context.Users.FirstOrDefaultAsync(u => u.Id == id && u.IsActive);

        public async Task<User?> GetByUsernameAsync(string username)
            => await _context.Users.FirstOrDefaultAsync(x => x.Username == username && x.IsActive);

        public async Task UpdateAsync(User user)
        {
            _context.Users.Update(user);
            await _context.SaveChangesAsync();
        }
    }
}

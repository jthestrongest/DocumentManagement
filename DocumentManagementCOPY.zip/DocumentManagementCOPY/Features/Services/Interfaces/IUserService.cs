using DocumentManagement.Features.Data.Models;

namespace DocumentManagement.Features.Services.Interfaces   
{
    public interface IUserService   
    {
        Task Register(User user);
        Task RegisterAdmin(User user);
        Task<User?> Login(string username, string password);
        Task<List<User>> GetAllUsers();
        Task<User?> GetUserById(int id);
        Task UpdateUser(User user);
        Task UpdatePassword(int userId, string currentPassword, string newPassword);
        Task DeleteUser(int id);
    }
}

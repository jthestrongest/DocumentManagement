using DocumentManagement.Features.Data.Models;

namespace DocumentManagement.Features.Services.Interfaces
{
    public interface IDocumentService
    {
        Task<List<Document>> GetAllDocumentsAsync();
        Task<Document?> GetDocumentByIdAsync(int id);
        Task<List<Document>> GetUserDocumentsAsync(int userId);
        Task UploadDocumentAsync(Document document, Stream fileStream);
        Task UpdateDocumentAsync(Document document);
        Task DeleteDocumentAsync(int id);
        Task<Stream> DownloadDocumentAsync(int id);
    }
}

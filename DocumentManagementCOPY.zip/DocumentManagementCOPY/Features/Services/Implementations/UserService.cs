using DocumentManagement.Features.Data.Enums;
using DocumentManagement.Features.Data.Models;
using DocumentManagement.Features.Repositories.Interfaces;
using DocumentManagement.Features.Services.Interfaces;
using System.Security.Cryptography;
using System.Text;

namespace DocumentManagement.Features.Services.Implementations
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _repo;
        public UserService(IUserRepository repo)
        {
            _repo = repo;
        }
        public Task DeleteUser(int id) => _repo.DeleteAsync(id);

        public Task<List<User>> GetAllUsers() => _repo.GetAllAsync();

        public Task<User?> GetUserById(int id) => _repo.GetByIdAsync(id);

        public async Task<User?> Login(string username, string password)
        {
            var user = await _repo.GetByUsernameAsync(username);

            if (user == null) { return null; }

            if (user.Password != Hash(password))
            { return null; }

            return user;
        }

        public async Task Register(User user)
        {
            var existingUser = await _repo.GetByUsernameAsync(user.Username);
            if (existingUser != null)
            {
                throw new Exception("Username already exists");
            }

            user.Password = Hash(user.Password);
            user.Role = Roles.User;
            user.IsActive = true;

            await _repo.AddAsync(user);
        }

        public async Task RegisterAdmin(User user)
        {
            var existingUser = await _repo.GetByUsernameAsync(user.Username);
            if (existingUser != null)
            {
                throw new Exception("Username already exists");
            }

            user.Password = Hash(user.Password);
            user.Role = Roles.Admin;
            user.IsActive = true;

            await _repo.AddAsync(user);
        }

        public Task UpdateUser(User user) => _repo.UpdateAsync(user);

        public async Task UpdatePassword(int userId, string currentPassword, string newPassword)
        {
            var user = await _repo.GetByIdAsync(userId);
            if (user == null)
            {
                throw new Exception("User not found");
            }

            if (user.Password != Hash(currentPassword))
            {
                throw new Exception("Current password is incorrect");
            }

            user.Password = Hash(newPassword);
            await _repo.UpdateAsync(user);
        }

        private string Hash(string input)
        {
            using var sha = SHA256.Create();
            return Convert.ToHexString(
                sha.ComputeHash(Encoding.UTF8.GetBytes(input))
            );
        }
    }
}

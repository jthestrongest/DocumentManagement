/*
using DocumentManagement.Features.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace DocumentManagement.Features.Services.Implementations
{
    [Route("api/documents")]
    [ApiController]
    public class DocumentController : ControllerBase
    {
        private readonly IDocumentService _documentService;

        public DocumentController(IDocumentService documentService)
        {
            _documentService = documentService;
        }

        [HttpGet("download/{id}")]
        public async Task<IActionResult> Download(int id)
        {
            try
            {
                var document = await _documentService.GetDocumentByIdAsync(id);
                if (document == null)
                    return NotFound("Document not found");

                var stream = await _documentService.DownloadDocumentAsync(id);
                return File(stream, document.FileType, document.FileName);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("view/{id}")]
        public async Task<IActionResult> View(int id)
        {
            try
            {
                var document = await _documentService.GetDocumentByIdAsync(id);
                if (document == null)
                    return NotFound("Document not found");

                var stream = await _documentService.DownloadDocumentAsync(id);
                
                // For viewing, we want to set the Content-Disposition to inline
                Response.Headers.Append("Content-Disposition", $"inline; filename=\"{document.FileName}\"");
                return File(stream, document.FileType);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
*/

using DocumentManagement.Features.Data.Models;
using DocumentManagement.Features.Repositories.Interfaces;
using DocumentManagement.Features.Services.Interfaces;
using Microsoft.AspNetCore.Components.Authorization;
using DocumentManagement.Features.Data.Enums;
using System.Security.Claims;
using DocumentManagement.Features.Helpers;

namespace DocumentManagement.Features.Services.Implementations
{
    public class DocumentService : IDocumentService
    {
        private readonly IDocumentRepository _repo;
        private readonly IWebHostEnvironment _env;
        private readonly AuthenticationStateProvider _authStateProvider;

        public DocumentService(IDocumentRepository repo, IWebHostEnvironment env, AuthenticationStateProvider authStateProvider)
        {
            _repo = repo;
            _env = env;
            _authStateProvider = authStateProvider;
        }

        public async Task<List<Document>> GetAllDocumentsAsync()
        {
            var documents = await _repo.GetAllAsync();
            var authState = await _authStateProvider.GetAuthenticationStateAsync();
            var user = authState.User;

            if (user.IsInRole(Roles.Admin.ToString()))
            {
                return documents;
            }

            // For non-admins, filter out admin uploads
            return documents.Where(d => d.UploadedByUser?.Role != Roles.Admin).ToList();
        }

        public async Task<Document?> GetDocumentByIdAsync(int id)
        {
            var document = await _repo.GetByIdAsync(id);
            if (document == null) return null;

            // Note: We allow GetById without strict role checks to ensure download/view links work
            // even when called from anonymous API contexts. Visibility is primarily controlled
            // via GetAllDocumentsAsync which filters the lists shown to users.
            
            return document;
        }

        public Task<List<Document>> GetUserDocumentsAsync(int userId) => _repo.GetByUserIdAsync(userId);

        public async Task UploadDocumentAsync(Document document, Stream fileStream)
        {
            try
            {
                // Block video uploads
                if (DocumentHelper.IsVideoFile(document.FileName, document.FileType))
                {
                    throw new InvalidOperationException("Video files are not allowed for upload.");
                }

                string uploadDir = Path.Combine(_env.ContentRootPath, "uploads");

                if (!Directory.Exists(uploadDir))
                {
                    Directory.CreateDirectory(uploadDir);
                }

                if (fileStream == null || fileStream.Length == 0)
                {
                    throw new InvalidOperationException("File stream is empty or invalid");
                }

                if (fileStream.CanSeek)
                {
                    fileStream.Seek(0, SeekOrigin.Begin);
                }

                string fileExtension = Path.GetExtension(document.FileName);
                string uniqueFileName = $"{Guid.NewGuid()}_{DateTime.Now:yyyyMMddHHmmss}{fileExtension}";
                string filePath = Path.Combine(uploadDir, uniqueFileName);

                using (var fileStream2 = new FileStream(filePath, FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    await fileStream.CopyToAsync(fileStream2);
                    await fileStream2.FlushAsync();
                }

                document.FilePath = filePath;
                document.FileName = uniqueFileName;
                document.UploadedDate = DateTime.UtcNow;
                document.IsActive = true;

                await _repo.AddAsync(document);
            }
            catch (Exception ex)
            {
                throw new Exception($"Document upload failed: {ex.Message}", ex);
            }
        }

        public Task UpdateDocumentAsync(Document document) => _repo.UpdateAsync(document);

        public async Task DeleteDocumentAsync(int id)
        {
            try
            {
                var document = await _repo.GetByIdAsync(id);
                if (document == null) return;

                if (!string.IsNullOrEmpty(document.FilePath) && File.Exists(document.FilePath))
                {
                    File.Delete(document.FilePath);
                }

                await _repo.DeleteAsync(id);
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to delete document: {ex.Message}", ex);
            }
        }

        public async Task<Stream> DownloadDocumentAsync(int id)
        {
            var document = await GetDocumentByIdAsync(id);
            if (document == null)
                throw new Exception("Document not found or access denied");

            if (!File.Exists(document.FilePath))
                throw new Exception("File not found on server");

            return File.OpenRead(document.FilePath);
        }
    }
}

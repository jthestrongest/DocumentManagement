# Project Structure & File Inventory

## 📁 Solution Overview: DocumentManagement.csproj

### Core Application Files

#### Program.cs
- Application startup configuration
- Service registration (MudBlazor, EF Core, DI)
- Database context configuration
- Authentication setup

#### appsettings.json
- MySQL connection string: `documentdb`
- Environment configuration

---

## 📂 Features Folder Structure

### /Features/Data

#### AppDbContext.cs
- Entity Framework DbContext
- DbSets for Users and Documents

#### /Models
- **BaseModel.cs** - Base class with audit fields (CreatedBy, CreatedAt, etc.)
- **User.cs** - User entity (Id, Name, Email, Username, Password, Role, IsActive)
- **Document.cs** - Document entity (Id, Name, Description, FilePath, FileSize, etc.)

#### /Enums
- **Roles.cs** - User roles enumeration (Admin, User)

### /Features/Repositories

#### /Interfaces
- **IUserRepository.cs** - User data access interface
- **IDocumentRepository.cs** - Document data access interface
- **IAuthRepository.cs** - Auth repository interface

#### /Implementations
- **UserRepository.cs** - User repository with soft delete
- **DocumentRepository.cs** - Document repository with soft delete
- **AuthRepository.cs** - Authentication repository

### /Features/Services

#### /Interfaces
- **IUserService.cs** - User service interface
- **IDocumentService.cs** - Document service interface

#### /Implementations
- **UserService.cs** - User service with registration, login, password hashing
- **DocumentService.cs** - Document service with upload, search, download

### /Features/Helpers
- **AuthStateProvider.cs** - Custom authentication state provider
- **DeleteConfirmDialog.razor** - Reusable delete confirmation dialog
- **RedirectToLogin.razor** - Redirect component for unauthorized access

---

## 🎨 Components Folder Structure

### /Components

#### App.razor
- Root component
- Routes configuration
- Theme provider

#### _Imports.razor
- Global imports for components

#### Routes.razor
- Application routing configuration
- AuthorizeView setup

#### /Layout

**MainLayout.razor**
- Main application layout
- AppBar with theme toggle and logout
- Navigation drawer

**MainLayout.razor.css**
- Layout styling

**NavMenu.razor**
- Navigation menu with role-based links
  - All Users: Home, Documents, Search, Settings, Help
  - Admins: Dashboard, Users, Activity Log, Register Admin

**AuthLayout.razor**
- Auth page layout (login/register pages)

### /Pages

#### Authenticated Pages

**Home.razor**
- Dashboard/welcome page
- Shows personalized greeting
- Quick navigation links

**Documents.razor**
- Main documents list
- Table of all documents
- Download/delete buttons
- Upload button link

**DocumentUpload.razor**
- Document upload form
- File selection
- Progress indicator
- Upload confirmation

**DocumentSearch.razor**
- Advanced search page
- Search by name/description
- Filter by file type
- Results table
- View/download actions

**Settings.razor**
- User account settings
- Password change
- Preferences (notifications, items per page)
- Security information

**Help.razor**
- Help documentation
- Getting Started guide
- How-To tutorials
- FAQ section
- Support contact information

**Dashboard.razor** (Admin Only)
- Statistics cards (users, documents, admins, storage)
- Recent documents list
- System metrics

**ActivityLog.razor** (Admin Only)
- Activity timeline
- Search activities
- Filter by type
- User action tracking

#### Auth Pages (/Pages/Auth)

**Login.razor**
- Login form
- Username/password fields
- Error messages
- Register link

**RegisterUserNew.razor**
- User registration form
- Name, email, username, password fields
- Role selector dropdown
- Auto-login after registration

**RegisterAdmin.razor**
- Admin registration form
- Admin-specific registration

**UserList.razor** (Admin Only)
- List of all users
- Edit/delete buttons
- Add user button

**UserEntry.razor** (Admin Only)
- Create/edit user form
- Role assignment

#### System Pages

**Counter.razor**
- Example counter page

**Weather.razor**
- Example weather page

**Error.razor**
- Error display page

---

## 🗄️ Migrations Folder

All Entity Framework migrations:

1. **20260410031735_InitialCreate**
   - Initial database schema

2. **20260410032302_AddDocumentTable**
   - Document table creation

3. **20260411104118_AddUserTable**
   - User table creation

4. **20260411111550_AddIsActiveToUsers**
   - Soft delete column for users (IsActive)

5. **20260411124624_IncreasePasswordFieldLength**
   - Password field from 30 to 256 characters

6. **20260411125751_UpdateDocumentModel**
   - Enhanced document model with metadata fields

**AppDbContextModelSnapshot.cs**
- Current model snapshot for migrations

---

## 📄 Documentation Files

### FEATURES.md
- Complete feature list
- All system capabilities
- Database models
- Technical stack
- Testing checklist

### QUICKSTART.md
- Quick start guide
- User workflows
- Page reference table
- Troubleshooting
- Tips & tricks

### PROJECT_STRUCTURE.md (This file)
- File inventory
- Folder organization
- Component overview

---

## 📊 Database Schema

### Users Table
```sql
CREATE TABLE Users (
    Id INT PRIMARY KEY,
    Name VARCHAR(100),
    Email VARCHAR(100),
    Username VARCHAR(20) UNIQUE,
    Password VARCHAR(256),
    Role VARCHAR(50),
    IsActive BIT,
    CreatedBy VARCHAR(MAX),
    CreatedAt DATETIME,
    UpdatedBy VARCHAR(MAX),
    UpdatedAt VARCHAR(MAX)
);
```

### Documents Table
```sql
CREATE TABLE Documents (
    Id INT PRIMARY KEY,
    Name VARCHAR(255),
    Description VARCHAR(1000),
    FileName VARCHAR(MAX),
    FilePath VARCHAR(MAX),
    FileSize BIGINT,
    FileType VARCHAR(50),
    UploadedDate DATETIME,
    UploadedByUserId INT FOREIGN KEY,
    IsActive BIT,
    CreatedBy VARCHAR(MAX),
    CreatedAt DATETIME,
    UpdatedBy VARCHAR(MAX),
    UpdatedAt VARCHAR(MAX)
);
```

---

## 🎯 Key File Functions

| File | Purpose | Type |
|------|---------|------|
| Program.cs | Application startup | Backend Config |
| AuthStateProvider.cs | Auth management | Backend Service |
| UserService.cs | User business logic | Backend Service |
| DocumentService.cs | Document business logic | Backend Service |
| UserRepository.cs | User data access | Backend Data |
| DocumentRepository.cs | Document data access | Backend Data |
| Home.razor | Welcome page | Frontend |
| Documents.razor | Document list | Frontend |
| Settings.razor | User settings | Frontend |
| Dashboard.razor | Admin dashboard | Frontend |
| MainLayout.razor | App layout | Frontend |
| NavMenu.razor | Navigation | Frontend |

---

## 🔄 Request Flow Example: Login

```
1. User enters credentials on Login.razor
2. Form submits to LoginUser() method
3. UserService.Login(username, password) called
4. Password hashed and compared to database
5. If valid, AuthStateProvider.SetUser() called
6. Navigation.NavigateTo("/") redirects to home
7. AuthStateProvider notifies listeners
8. MainLayout renders authenticated UI
```

---

## 🔄 Request Flow Example: Upload

```
1. User selects file on DocumentUpload.razor
2. Form submits OnValidSubmit
3. Document metadata captured (name, description, role)
4. IDocumentService.UploadDocumentAsync() called
5. File saved to /uploads folder with unique name
6. Document metadata saved to database
7. User redirected to /documents
8. Success notification shown
```

---

## 🌐 Component Dependencies

```
App.razor
├── Routes.razor
│   ├── MainLayout.razor (Authenticated)
│   │   ├── NavMenu.razor
│   │   ├── MainLayout.razor.css
│   │   └── @Body
│   │       ├── Home.razor
│   │       ├── Documents.razor
│   │       ├── DocumentSearch.razor
│   │       ├── Dashboard.razor (Admin)
│   │       ├── UserList.razor (Admin)
│   │       ├── ActivityLog.razor (Admin)
│   │       └── ... other pages
│   │
│   └── AuthLayout.razor (Public)
│       ├── Login.razor
│       ├── RegisterUserNew.razor
│       └── RegisterAdmin.razor
│
└── Helpers/
    ├── DeleteConfirmDialog.razor
    └── AuthStateProvider.cs
```

---

## 📦 NuGet Dependencies

- **MudBlazor** 9.3.0 - UI Components
- **EntityFrameworkCore** 9.0.5 - ORM
- **Pomelo.EntityFrameworkCore.MySql** - MySQL Provider
- **Microsoft.AspNetCore.Components.Authorization** - Auth

---

## 🚀 Build & Deployment

### Build Command:
```powershell
dotnet build
```

### Run Command:
```powershell
dotnet run
```

### Publish:
```powershell
dotnet publish -c Release
```

### Create Migration:
```powershell
dotnet ef migrations add MigrationName
```

### Update Database:
```powershell
dotnet ef database update
```

---

## 📝 File Naming Conventions

- **Components**: PascalCase.razor (e.g., `Documents.razor`)
- **Pages**: PascalCase in /Pages folder (e.g., `/Pages/Documents.razor`)
- **Services**: IServiceName.cs and ServiceName.cs (e.g., `IUserService.cs`)
- **Models**: PascalCase.cs (e.g., `User.cs`)
- **Migrations**: YYYYMMDDHHMMSS_MigrationName.cs

---

## 🔐 Security Features by File

| File | Security Feature |
|------|------------------|
| AuthStateProvider.cs | Authentication state management |
| UserService.cs | Password hashing (SHA256) |
| UserRepository.cs | Soft delete for users |
| DocumentRepository.cs | Soft delete for documents |
| MainLayout.razor | Role-based UI rendering |
| Routes.razor | Authorization routing |

---

## ✅ Production Readiness Checklist

- [x] Authentication implemented
- [x] Authorization/RBAC implemented
- [x] Password hashing implemented
- [x] Soft delete implemented
- [x] Error handling implemented
- [x] Database migrations implemented
- [x] UI/UX complete
- [x] Documentation complete
- [ ] Email notifications (future)
- [ ] Audit logging to database (future)
- [ ] API endpoints (future)
- [ ] Docker support (future)

---

**Project Status:** ✅ **COMPLETE & FULLY FUNCTIONAL**  
**Last Updated:** April 11, 2026  
**Version:** 1.0.0
